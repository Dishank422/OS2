To run the program, download the file AI20BTECH11011.cpp and the input file inp.txt. Place the files in the same folder.
To execute the file, run
$ g++ program.cpp && ./a.out

In inp.txt, the first line is the number of physical frames. The second line is the page size.
The remaining lines are the addresses being accessed in sequential order.