#include "types.h"
#include "user.h"
#include "date.h"

//uncomment global lines for global array and local line for local array.
//int b[10000]; //global

int main(void)
{
    //int b[10000]; //local
    //b[0] = 2; //local
    pgtprint();
    //printf(2, "%d\n", b[0]); //global and local
    exit();
}


